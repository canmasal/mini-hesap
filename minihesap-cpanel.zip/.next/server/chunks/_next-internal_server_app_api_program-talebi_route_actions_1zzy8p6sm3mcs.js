module.exports=[10605,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_program-talebi_route_actions_1zzy8p6sm3mcs.js.map