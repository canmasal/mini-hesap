module.exports=[55817,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_borsa_route_actions_20gk095bsg2ej.js.map