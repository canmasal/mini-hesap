module.exports=[75168,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("main",{className:"admin",children:a})},"dynamic",0,"force-dynamic","metadata",0,{title:"Yönetim",robots:{index:!1,follow:!1,nocache:!0,googleBot:{index:!1,follow:!1}}}])},43433,function(a){a.n(a.i(75168))}];

//# sourceMappingURL=app_yonetim_layout_tsx_1qf1t0-r94c-g._.js.map