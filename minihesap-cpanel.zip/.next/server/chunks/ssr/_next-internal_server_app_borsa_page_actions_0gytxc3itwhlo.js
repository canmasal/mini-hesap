module.exports=[35599,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_borsa_page_actions_0gytxc3itwhlo.js.map