module.exports=[79217,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_altin-fiyatlari_page_actions_0rqcfhe0oixjp.js.map