module.exports=[13547,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_iade-kosullari_page_actions_0w3to3zp-d74v.js.map