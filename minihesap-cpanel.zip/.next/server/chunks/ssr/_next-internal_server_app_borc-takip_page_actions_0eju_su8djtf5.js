module.exports=[43418,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_borc-takip_page_actions_0eju_su8djtf5.js.map