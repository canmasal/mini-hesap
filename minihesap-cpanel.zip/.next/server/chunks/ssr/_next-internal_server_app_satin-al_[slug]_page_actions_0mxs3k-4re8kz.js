module.exports=[99198,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_satin-al_%5Bslug%5D_page_actions_0mxs3k-4re8kz.js.map