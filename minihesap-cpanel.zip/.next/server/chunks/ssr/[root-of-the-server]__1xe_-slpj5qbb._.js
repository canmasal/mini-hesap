module.exports=[[39585,a=>{function b(){return!!(process.env.RESEND_API_KEY&&process.env.MAIL_FROM)}function c(a){return String(a??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}async function d(a,d){if(!b())return{sent:!1,reason:"yapilandirilmadi"};try{let b,e,f,g=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:process.env.MAIL_FROM,to:[a.email],subject:`Siparişiniz hazır — ${a.productTitle}`,html:(b=c(a.fullName.split(" ")[0]??""),e=c(a.productTitle),f=(a.amountKurus/100).toLocaleString("tr-TR",{minimumFractionDigits:2}),`
<div style="font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;max-width:560px;margin:0 auto;color:#10231a">
  <div style="background:#16a34a;color:#fff;padding:22px 24px;border-radius:14px 14px 0 0">
    <div style="font-size:20px;font-weight:800">MiniHesap</div>
    <div style="font-size:13px;opacity:.9;margin-top:4px">Siparişiniz hazır</div>
  </div>

  <div style="border:1px solid #dce7df;border-top:0;border-radius:0 0 14px 14px;padding:24px">
    <p style="margin:0 0 14px">Merhaba ${b},</p>

    <p style="margin:0 0 18px;line-height:1.7">
      <strong>${e}</strong> i\xe7in \xf6demeniz onaylandı. Dosyanızı aşağıdaki
      bağlantıdan indirebilirsiniz.
    </p>

    <p style="margin:0 0 24px">
      <a href="${d}"
         style="display:inline-block;background:#16a34a;color:#fff;text-decoration:none;
                padding:14px 26px;border-radius:999px;font-weight:800">
        Siparişime Git ve İndir
      </a>
    </p>

    <div style="background:#f8faf9;border:1px solid #e5eee8;border-radius:12px;padding:16px;font-size:14px;line-height:1.7">
      <div><strong>Sipariş no:</strong> ${c(a.id)}</div>
      <div><strong>Tutar:</strong> ${f} ₺</div>
      <div style="margin-top:8px;color:#617066">
        Bu bağlantı 30 g\xfcn boyunca ge\xe7erlidir ve en fazla 10 indirme hakkı tanır.
        Sayfayı yer imlerinize eklemenizi \xf6neririz.
      </div>
    </div>

    <p style="margin:20px 0 0;font-size:13px;color:#617066;line-height:1.7">
      Sorun yaşarsanız bu e-postayı yanıtlayarak sipariş numaranızla birlikte
      bize yazabilirsiniz.
    </p>

    <p style="margin:18px 0 0;font-size:12px;color:#94a39a">
      MiniHesap \xb7 minihesap.net<br>
      Bu e-posta ${c(a.email)} adresine bir satın alma nedeniyle g\xf6nderildi.
    </p>
  </div>
</div>`.trim())})});if(!g.ok){let a=await g.text();return console.error("Sipariş e-postası gönderilemedi:",g.status,a),{sent:!1,reason:`http_${g.status}`}}return{sent:!0}}catch(a){return console.error("Sipariş e-postası gönderilemedi:",a),{sent:!1,reason:"istisna"}}}a.s(["Z",0,b,"V",0,d])},43716,a=>{var b=a.i(22734),c=a.i(14747);class d{file=c.default.join(process.cwd(),"private","orders.json");async readAll(){try{let a=await b.promises.readFile(this.file,"utf8"),c=JSON.parse(a);return Array.isArray(c)?c:[]}catch{return[]}}async writeAll(a){await b.promises.mkdir(c.default.dirname(this.file),{recursive:!0}),await b.promises.writeFile(this.file,JSON.stringify(a,null,2),"utf8")}async create(a){let b=await this.readAll();b.unshift(a),await this.writeAll(b)}async get(a){return(await this.readAll()).find(b=>b.id===a)??null}async findByProviderRef(a){return(await this.readAll()).find(b=>b.providerRef===a)??null}async update(a,b){let c=await this.readAll(),d=c.findIndex(b=>b.id===a);return -1===d?null:(c[d]={...c[d],...b},await this.writeAll(c),c[d])}async list(a=100){return(await this.readAll()).slice(0,a)}}class e{url;key;constructor(a,b){this.url=a,this.key=b}endpoint(a=""){return`${this.url}/rest/v1/orders${a}`}headers(a={}){return{apikey:this.key,Authorization:`Bearer ${this.key}`,"Content-Type":"application/json",...a}}async create(a){let b=await fetch(this.endpoint(),{method:"POST",headers:this.headers({Prefer:"return=minimal"}),body:JSON.stringify(a)});if(!b.ok)throw Error(`Sipariş kaydedilemedi (${b.status})`)}async first(a){let b=await fetch(this.endpoint(a),{headers:this.headers()});return b.ok?(await b.json())[0]??null:null}async get(a){return this.first(`?id=eq.${encodeURIComponent(a)}&limit=1`)}async findByProviderRef(a){return this.first(`?providerRef=eq.${encodeURIComponent(a)}&limit=1`)}async update(a,b){let c=await fetch(this.endpoint(`?id=eq.${encodeURIComponent(a)}`),{method:"PATCH",headers:this.headers({Prefer:"return=representation"}),body:JSON.stringify(b)});return c.ok?(await c.json())[0]??null:null}async list(a=100){let b=await fetch(this.endpoint(`?order=createdAt.desc&limit=${a}`),{headers:this.headers()});return b.ok?await b.json():[]}}let f=null;a.s(["L",0,function(){if(f)return f;let a=process.env.SUPABASE_URL,b=process.env.SUPABASE_SERVICE_KEY;return f=a&&b?new e(a,b):new d},"o",0,function(){return process.env.SUPABASE_URL&&process.env.SUPABASE_SERVICE_KEY?"supabase":"dosya"}])},20515,a=>{a.s(["N",0,30,"m",0,10])},717,(a,b,c)=>{b.exports=a.r(24951).vendored["react-rsc"].React}],54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},70406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},20635,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},56704,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(a,b,c)=>{b.exports=a.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},81111,(a,b,c)=>{b.exports=a.x("node:stream",()=>require("node:stream"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1xe_-slpj5qbb._.js.map