module.exports=[53193,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_program-talebi_page_actions_0qb8s_4wo0ctf.js.map