module.exports=[35222,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_on-muhasebe_page_actions_1k2xcnsh_ei_h.js.map