module.exports=[67772,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_rehber_page_actions_192yk2x6qtsiz.js.map