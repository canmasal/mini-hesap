module.exports=[54032,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mesafeli-satis-sozlesmesi_page_actions_0iac4pd_6er-3.js.map