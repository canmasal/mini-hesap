module.exports=[52336,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_guncel-rakamlar_page_actions_01e602fmzybcs.js.map