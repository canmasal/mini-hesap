module.exports=[97295,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hesaplamalar_%5Bslug%5D_page_actions_1pro8t5fxk3qv.js.map