module.exports=[46669,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reklam_page_actions_0f-_pfuz67rbf.js.map