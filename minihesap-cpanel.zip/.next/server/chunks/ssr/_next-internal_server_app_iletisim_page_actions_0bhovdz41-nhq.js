module.exports=[6529,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_iletisim_page_actions_0bhovdz41-nhq.js.map