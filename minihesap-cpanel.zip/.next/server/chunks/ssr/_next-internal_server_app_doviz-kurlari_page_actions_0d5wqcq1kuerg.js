module.exports=[82606,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_doviz-kurlari_page_actions_0d5wqcq1kuerg.js.map