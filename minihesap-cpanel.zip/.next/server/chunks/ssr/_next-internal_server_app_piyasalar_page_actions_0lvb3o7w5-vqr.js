module.exports=[6083,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_piyasalar_page_actions_0lvb3o7w5-vqr.js.map