module.exports=[37334,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_on-bilgilendirme_page_actions_09nms38w_praw.js.map