module.exports=[34428,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hesaplamalar_page_actions_13va6jb6cidob.js.map