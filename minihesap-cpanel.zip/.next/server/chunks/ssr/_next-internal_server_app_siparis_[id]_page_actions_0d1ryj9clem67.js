module.exports=[39113,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_siparis_%5Bid%5D_page_actions_0d1ryj9clem67.js.map