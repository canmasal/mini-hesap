module.exports=[78985,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hesapla_%5Bslug%5D_page_actions_1eq34c378g175.js.map