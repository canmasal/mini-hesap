module.exports=[[59310,a=>{let b={src:a.i(76789).default,width:180,height:180};a.s(["default",0,b])},48760,a=>{let b={src:a.i(71385).default,width:64,height:64};a.s(["default",0,b])},39585,a=>{function b(){return!!(process.env.RESEND_API_KEY&&process.env.MAIL_FROM)}function c(a){return String(a??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}async function d(a,d){if(!b())return{sent:!1,reason:"yapilandirilmadi"};try{let b,e,f,g=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:process.env.MAIL_FROM,to:[a.email],subject:`Siparişiniz hazır — ${a.productTitle}`,html:(b=c(a.fullName.split(" ")[0]??""),e=c(a.productTitle),f=(a.amountKurus/100).toLocaleString("tr-TR",{minimumFractionDigits:2}),`
<div style="font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;max-width:560px;margin:0 auto;color:#10231a">
  <div style="background:#16a34a;color:#fff;padding:22px 24px;border-radius:14px 14px 0 0">
    <div style="font-size:20px;font-weight:800">MiniHesap</div>
    <div style="font-size:13px;opacity:.9;margin-top:4px">Siparişiniz hazır</div>
  </div>

  <div style="border:1px solid #dce7df;border-top:0;border-radius:0 0 14px 14px;padding:24px">
    <p style="margin:0 0 14px">Merhaba ${b},</p>

    <p style="margin:0 0 18px;line-height:1.7">
      <strong>${e}</strong> i\xe7in \xf6demeniz onaylandı. Dosyanızı aşağıdaki
      bağlantıdan indirebilirsiniz.
    </p>

    <p style="margin:0 0 24px">
      <a href="${d}"
         style="display:inline-block;background:#16a34a;color:#fff;text-decoration:none;
                padding:14px 26px;border-radius:999px;font-weight:800">
        Siparişime Git ve İndir
      </a>
    </p>

    <div style="background:#f8faf9;border:1px solid #e5eee8;border-radius:12px;padding:16px;font-size:14px;line-height:1.7">
      <div><strong>Sipariş no:</strong> ${c(a.id)}</div>
      <div><strong>Tutar:</strong> ${f} ₺</div>
      <div style="margin-top:8px;color:#617066">
        Bu bağlantı 30 g\xfcn boyunca ge\xe7erlidir ve en fazla 10 indirme hakkı tanır.
        Sayfayı yer imlerinize eklemenizi \xf6neririz.
      </div>
    </div>

    <p style="margin:20px 0 0;font-size:13px;color:#617066;line-height:1.7">
      Sorun yaşarsanız bu e-postayı yanıtlayarak sipariş numaranızla birlikte
      bize yazabilirsiniz.
    </p>

    <p style="margin:18px 0 0;font-size:12px;color:#94a39a">
      MiniHesap \xb7 minihesap.net<br>
      Bu e-posta ${c(a.email)} adresine bir satın alma nedeniyle g\xf6nderildi.
    </p>
  </div>
</div>`.trim())})});if(!g.ok){let a=await g.text();return console.error("Sipariş e-postası gönderilemedi:",g.status,a),{sent:!1,reason:`http_${g.status}`}}return{sent:!0}}catch(a){return console.error("Sipariş e-postası gönderilemedi:",a),{sent:!1,reason:"istisna"}}}a.s(["Z",0,b,"V",0,d])},47264,a=>{function b(){return{iban:process.env.HAVALE_IBAN??"",alici:process.env.HAVALE_ALICI??"",banka:process.env.HAVALE_BANKA??""}}a.s(["Q",0,b,"X",0,{id:"havale",label:"Havale / EFT",isConfigured(){let a=b();return!!(a.iban&&a.alici)},async startCheckout(a,b){if(!this.isConfigured())throw Error("HAVALE_IBAN veya HAVALE_ALICI tanımlı değil.");return{kind:"redirect",url:b.successUrl}},verifyWebhook:async()=>null}])},717,(a,b,c)=>{b.exports=a.r(24951).vendored["react-rsc"].React}],54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},70406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},20635,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},43285,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/dynamic-access-async-storage.external.js",()=>require("next/dist/server/app-render/dynamic-access-async-storage.external.js"))},56704,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(a,b,c)=>{b.exports=a.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(a,b,c)=>{b.exports=a.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},81111,(a,b,c)=>{b.exports=a.x("node:stream",()=>require("node:stream"))},76789,a=>{a.v("/_next/static/media/apple-icon.1h0ilq0jx352h.png"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},71385,a=>{a.v("/_next/static/media/icon.3th8qu4ajejas.svg"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},14465,(a,b,c)=>{(()=>{"use strict";var a={86:a=>{a.exports=function(a,b){return"string"==typeof a?g(a):"number"==typeof a?f(a,b):null},a.exports.format=f,a.exports.parse=g;var b=/\B(?=(\d{3})+(?!\d))/g,c=/(?:\.0*|(\.[^0]+)0+)$/,d={b:1,kb:1024,mb:1048576,gb:0x40000000,tb:0x10000000000,pb:0x4000000000000},e=/^((-|\+)?(\d+(?:\.\d+)?)) *(kb|mb|gb|tb|pb)$/i;function f(a,e){if(!Number.isFinite(a))return null;var f=Math.abs(a),g=e&&e.thousandsSeparator||"",h=e&&e.unitSeparator||"",i=e&&void 0!==e.decimalPlaces?e.decimalPlaces:2,j=!!(e&&e.fixedDecimals),k=e&&e.unit||"";k&&d[k.toLowerCase()]||(k=f>=d.pb?"PB":f>=d.tb?"TB":f>=d.gb?"GB":f>=d.mb?"MB":f>=d.kb?"KB":"B");var l=(a/d[k.toLowerCase()]).toFixed(i);return j||(l=l.replace(c,"$1")),g&&(l=l.split(".").map(function(a,c){return 0===c?a.replace(b,g):a}).join(".")),l+h+k}function g(a){if("number"==typeof a&&!isNaN(a))return a;if("string"!=typeof a)return null;var b,c=e.exec(a),f="b";return c?(b=parseFloat(c[1]),f=c[4].toLowerCase()):(b=parseInt(a,10),f="b"),Math.floor(d[f]*b)}}},c={};function d(b){var e=c[b];if(void 0!==e)return e.exports;var f=c[b]={exports:{}},g=!0;try{a[b](f,f.exports,d),g=!1}finally{g&&delete c[b]}return f.exports}d.ab="/ROOT/node_modules/next/dist/compiled/bytes/",b.exports=d(86)})()}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0r--lhotu02k9._.js.map