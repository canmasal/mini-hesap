module.exports=[29514,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_premium_borc-takip_page_actions_1mjan2gh-vokd.js.map