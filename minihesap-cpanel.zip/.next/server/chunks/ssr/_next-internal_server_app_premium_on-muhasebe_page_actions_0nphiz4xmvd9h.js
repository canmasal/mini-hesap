module.exports=[38155,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_premium_on-muhasebe_page_actions_0nphiz4xmvd9h.js.map