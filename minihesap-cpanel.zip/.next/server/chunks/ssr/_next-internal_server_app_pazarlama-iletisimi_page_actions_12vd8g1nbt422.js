module.exports=[48336,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pazarlama-iletisimi_page_actions_12vd8g1nbt422.js.map