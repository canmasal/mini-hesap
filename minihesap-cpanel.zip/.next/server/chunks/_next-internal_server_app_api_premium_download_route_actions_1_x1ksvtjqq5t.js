module.exports=[3177,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_premium_download_route_actions_1_x1ksvtjqq5t.js.map