module.exports=[68640,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_siparis_olustur_route_actions_1_dp-3iwbcd-1.js.map