module.exports=[33566,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_piyasa_route_actions_1kce4ta-nyhz-.js.map