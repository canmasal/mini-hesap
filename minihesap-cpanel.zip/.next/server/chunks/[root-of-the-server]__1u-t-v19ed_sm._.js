module.exports=[[76636,e=>{function i(e){return String(e??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}async function r(e,r){if(!(process.env.RESEND_API_KEY&&process.env.MAIL_FROM))return{sent:!1,reason:"yapilandirilmadi"};try{let a,t,n,s=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:process.env.MAIL_FROM,to:[e.email],subject:`Siparişiniz hazır — ${e.productTitle}`,html:(a=i(e.fullName.split(" ")[0]??""),t=i(e.productTitle),n=(e.amountKurus/100).toLocaleString("tr-TR",{minimumFractionDigits:2}),`
<div style="font-family:system-ui,-apple-system,'Segoe UI',Arial,sans-serif;max-width:560px;margin:0 auto;color:#10231a">
  <div style="background:#16a34a;color:#fff;padding:22px 24px;border-radius:14px 14px 0 0">
    <div style="font-size:20px;font-weight:800">MiniHesap</div>
    <div style="font-size:13px;opacity:.9;margin-top:4px">Siparişiniz hazır</div>
  </div>

  <div style="border:1px solid #dce7df;border-top:0;border-radius:0 0 14px 14px;padding:24px">
    <p style="margin:0 0 14px">Merhaba ${a},</p>

    <p style="margin:0 0 18px;line-height:1.7">
      <strong>${t}</strong> i\xe7in \xf6demeniz onaylandı. Dosyanızı aşağıdaki
      bağlantıdan indirebilirsiniz.
    </p>

    <p style="margin:0 0 24px">
      <a href="${r}"
         style="display:inline-block;background:#16a34a;color:#fff;text-decoration:none;
                padding:14px 26px;border-radius:999px;font-weight:800">
        Siparişime Git ve İndir
      </a>
    </p>

    <div style="background:#f8faf9;border:1px solid #e5eee8;border-radius:12px;padding:16px;font-size:14px;line-height:1.7">
      <div><strong>Sipariş no:</strong> ${i(e.id)}</div>
      <div><strong>Tutar:</strong> ${n} ₺</div>
      <div style="margin-top:8px;color:#617066">
        Bu bağlantı 30 g\xfcn boyunca ge\xe7erlidir ve en fazla 10 indirme hakkı tanır.
        Sayfayı yer imlerinize eklemenizi \xf6neririz.
      </div>
    </div>

    <p style="margin:20px 0 0;font-size:13px;color:#617066;line-height:1.7">
      Sorun yaşarsanız bu e-postayı yanıtlayarak sipariş numaranızla birlikte
      bize yazabilirsiniz.
    </p>

    <p style="margin:18px 0 0;font-size:12px;color:#94a39a">
      MiniHesap \xb7 minihesap.net<br>
      Bu e-posta ${i(e.email)} adresine bir satın alma nedeniyle g\xf6nderildi.
    </p>
  </div>
</div>`.trim())})});if(!s.ok){let e=await s.text();return console.error("Sipariş e-postası gönderilemedi:",s.status,e),{sent:!1,reason:`http_${s.status}`}}return{sent:!0}}catch(e){return console.error("Sipariş e-postası gönderilemedi:",e),{sent:!1,reason:"istisna"}}}e.s(["f",0,r])},14585,e=>{e.s(["N",0,30,"m",0,10])},9294,e=>{function i(e){return e.trim().replace(/\/+$/,"").replace(/^(https?:\/\/)www\./i,"$1")}let r="https://minihesap.net",a=i(r||"https://minihesap.net"),t=i(r);e.s(["O",0,t,"A",0,a])}],93695,(e,i,r)=>{i.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1u-t-v19ed_sm._.js.map