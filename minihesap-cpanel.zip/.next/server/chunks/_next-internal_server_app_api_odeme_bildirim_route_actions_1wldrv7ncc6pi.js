module.exports=[52280,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_odeme_bildirim_route_actions_1wldrv7ncc6pi.js.map