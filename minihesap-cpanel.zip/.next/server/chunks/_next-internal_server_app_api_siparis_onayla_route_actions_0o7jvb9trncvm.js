module.exports=[15208,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_siparis_onayla_route_actions_0o7jvb9trncvm.js.map