var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[externals]__1_g5-dw3bqiid._.js")
R.c("server/chunks/_0zc7ty0ihqxb6._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_1n32_cshpygg5.js")
R.m(72168)
module.exports=R.m(72168).exports
