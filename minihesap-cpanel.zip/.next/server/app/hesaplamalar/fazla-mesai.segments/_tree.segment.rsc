:HL["/_next/static/chunks/1a5to67go0g87.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"fazla-mesai","s":[]},"h":65632,"c":"$Q3"}]]
1:[["children",{"s":"hesaplamalar","h":131136,"c":"$Q2"}]]
0:{"b":"52QQUzIBmR9t6zzOcXch2","t":{"t":{"s":"","h":131088,"c":"$Q1"}}}
